val viability =
  new ViabilityKernel
    with ZoneInput
    with ZoneK
    with GridSampler 
    with Consumer {
    def controls = (-0.5 to 0.5 by 0.1).map(Control(_))
    def zone = Seq((0.0, 2.0), (0.0, 3.0))
    def depth = 16
    def dimension = 2
  }

implicit lazy val rng = new Random(42)

val kernel = viability().lastWithTrace{ (tree, step) => println(step) }
println(kernel.volume)
